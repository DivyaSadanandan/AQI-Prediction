# -*- coding: utf-8 -*-
"""
Created on Sun Apr  4 12:50:02 2021

@author: rizwana
"""

from flask import Flask,render_template,request
import pickle
import numpy as np
app=Flask(__name__)
model=pickle.load(open('model.pkl','rb'))
@app.route('/')
def home():
    return render_template('check.html') #home page is index.html in template folder
@app.route('/predict',methods=['POST'])
def predict():
   
   values= [float(x) for x in request.form.values()]
   val = [np.array(values)]
   
   output=model.predict(val)
   output=output.item()
   aqi=round(output,2)
   
   def get_AQI_bucket(x):
    if x <= 50:
        return "Good"
    elif x <= 100:
        return "Satisfactory"
    elif x <= 200:
        return "Moderate"
    elif x <= 300:
        return "Poor"
    elif x <= 400:
        return "Very Poor"
    elif x > 400:
        return "Severe"
    else:
        return np.NaN
    
   aqi_bucket=get_AQI_bucket(aqi)
   
   text1="AQI is {}. ".format(str(aqi))
   text2="  The Quality of Air is {}".format(aqi_bucket)
   text=text1+text2
   print(text)
   return render_template ('result.html',prediction_text=" {}".format(text))
if __name__=='__main__':
    app.run(port=5000)