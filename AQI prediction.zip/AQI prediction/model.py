import pickle
import pandas as pd
import numpy as np


air_data=pd.read_csv('city_day.csv')

#imputaion using forward fill
air_data.fillna(method='ffill',inplace=True)
air_data.fillna(method="bfill",inplace=True)
air_data.isna().sum()

"""# Handling Outliers"""
Q1=np.percentile(air_data['AQI'],25,interpolation='midpoint')
Q2=np.percentile(air_data['AQI'],50,interpolation='midpoint')
Q3=np.percentile(air_data['AQI'],75,interpolation='midpoint')

IQR=Q3-Q1

low_limit=Q1-1.5*IQR
upper_limit=Q3+3*IQR

indx1=air_data['AQI']>upper_limit
air_data.loc[indx1].index

air_data.drop(air_data.loc[indx1].index,inplace=True)
air_data.shape


"""Feature Engineering"""

air_data['BTX'] = air_data['Benzene']+air_data['Toluene']+air_data['Xylene']

data=air_data.drop(['Benzene','Toluene','Xylene','AQI_Bucket'],axis=1)
data=data.drop([])
"""Splitting Dataset
"""

X=data.drop(['AQI'],axis=1)
y=data['AQI']

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(X,y,random_state=42,test_size=0.2)


#Random Forest


from sklearn.ensemble import RandomForestRegressor

rf=RandomForestRegressor()

"""Feature Importance and Feature Selection"""

#pd.Series(rf.feature_importances_,index=X.columns).sort_values(ascending=False)*100
#X=data.drop(['AQI'],axis=1)
#X=X.drop(['BTX','NH3','NO2','City','Date'],axis=1)
Features=['PM2.5','PM10','NO2','NOx','CO','SO2','O3','NH3'] #Only Major pollutants are considered as X\n",
X=data[Features]
y=data['AQI']
print(X.shape)
print(X.columns)

x_train,x_test,y_train,y_test=train_test_split(X,y,random_state=42,test_size=0.2)


#RFT after Hypertuning and selecting 7 features
rf1=RandomForestRegressor(n_estimators=50,random_state=42,max_depth=20)
rf1.fit(x_train,y_train)

y_pred=rf1.predict(x_test)

from sklearn.metrics import mean_squared_error,r2_score
print('Mean Squared Error',mean_squared_error(y_test,y_pred))
print('R2 score',r2_score(y_test,y_pred))

pickle.dump(rf1,open('model.pkl','wb'))

